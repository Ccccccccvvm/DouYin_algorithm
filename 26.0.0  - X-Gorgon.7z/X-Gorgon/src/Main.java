public class Main {
    static int[] TaBle_1 = new int[0x100];
    static int[] TaBle_2 = new int[0x14];

    public static void main(String[] args) {

        InitTaBle_1();
//        int[] data = {0x92, 0xf6, 0x9c, 0xd6, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x5, 0x4, 0x4, 0x60, 0x79, 0x40, 0x17};
//
//        int[] tmpTaBle = new int[20];
//        for (int i = 0; i < data.length; i++) {
//            if (i == 0) {
//                tmpTaBle[i] = TaBle_1[i + 1];
//            } else {
//                int a = TaBle_1[i + 1] + tmpTaBle[i - 1];
//                tmpTaBle[i] = a;
//                int w9 = tmpTaBle[i] / 100;
//                if (w9 > 0) {
//                    int w27 = tmpTaBle[i] - (w9 << 8);
//                    tmpTaBle[i] = w27 & 0xFF;
//                }
//
//
//            }
//        }
//        for (int j = 0; j < 20; j++) {
//            tmpTaBle[j] = TaBle_1[(TaBle_1[tmpTaBle[j]] + TaBle_1[tmpTaBle[j]]) & 0xff] ^ data[j];
//            System.out.println(Integer.toHexString(tmpTaBle[j]));
//        }
//        System.out.println("Hello world!");

    }

    static void InitTaBle_1() {

        int w8 = 0;
        int w9 = 0;
        int w22 = 0;
        int w23 = 0;
        int w27 = 0;
        int w10 = 0;
        int x2 = 0;
        int w4 = 0;
        int x5 = 6;
        int w5 = 0;
        int w3 = 0;
        int[] TmpKey = {0x4A, 0x0, 0x16, 0x77, 0x47, 0x6c, 0x0, 0xE0};
        for (int i = 0; i < TaBle_1.length; i++) {
            TaBle_1[i] = i;
        }
        for (int i = 0; i < TaBle_1.length; i++) {
            int x9 = i % 8;
            w9 = TmpKey[x9];
            w8 = w22 + i;
            w8 += w9;
            w9 = w8 / 0x100;
            w22 = w8 - (w9 << 8);
            w23 = TaBle_1[w22];
            TaBle_1[i] = w23;
//            System.out.println(Integer.toHexString(TaBle_1[i]));
        }
        w8 = 0;
        w9 = 0;
        w22 = 0;
        w23 = 0;
        w27 = 0;
        w10 = 0;
        int[] Data = {0x92, 0xF6, 0x9C, 0xD6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x04, 0x04, 0x60, 0x79, 0x40, 0x17};  //需要加密数据
        for (int i = 0; i < TaBle_2.length; i++) {
            w8 = TaBle_1[i + 1];
            w8 = w27 + w8;
            w9 = w8 / 0x100;
            w27 = w8 - (w9 << 8);
            w8 = TaBle_1[w27];
            TaBle_1[i + 1] = w8;
            TaBle_1[w27] = w8;
            w9 = TaBle_1[i + 1];
            w10 = Data[i];
            w8 = w9 + w8;
            w8 = w8 & 0xff;
            w8 = TaBle_1[w8];

            w8 = w8 ^ w10;
            TaBle_2[i] = w8;
            System.out.println("TaBle_2  " + Integer.toHexString(TaBle_2[i]));
        }
        w8 = 0;
        w9 = 0;
        w22 = 0;
        w23 = 0;
        w27 = 0;
        w10 = 0;
        x2 = 0;
        w4 = 0;
        x5 = 6;
        System.out.println("----------------------");
        int[] TmpTaBle = new int[20];
        for (int i = 0; i < Data.length; i++) {
            x2 = x2 + i;
            w4 = TaBle_2[i] >>> 4;
            int bitfield = (TaBle_2[i] >> 4) & 0xFF;
            w4 = bfi(w4, TaBle_2[i], 4, 8);
            TmpTaBle[i] = w4 & 0xff;
            System.out.println("TmpTaBle  " + Integer.toHexString(TmpTaBle[i]));
        }
        w8 = 0;
        w9 = 0;
        w22 = 0;
        w23 = 0;
        w27 = 0;
        w10 = 0;
        x2 = 0;
        w4 = 0;
        x5 = 6;
        w5 = 0;
        System.out.println("----------------------");
        for (int i = 0; i < Data.length - 1; i++) {
            w4 = TaBle_2[i + 1];
            w5 = TmpTaBle[i];
            w4 = w5 ^ w4;
            TmpTaBle[i] = w4;
            System.out.println("TmpTaBle " + Integer.toHexString(TmpTaBle[i]));
        }
        w8 = 0;
        w9 = 0;
        w22 = 0;
        w23 = 0;
        w27 = 0;
        w10 = 0;
        x2 = 0;
        w4 = 0;
        x5 = 6;
        w5 = 0;
        w3 = 0;
        w4 = ~0x55 & (TmpTaBle[0] << 1);
        w3 = 0x55 & (TmpTaBle[0] >>> 1);
        w3 = w4 | w3;
        w4 = w3 << 2;
        w4 = w4 & 0xffffffcf;
        w3 = 0x33 & (w3 >>> 2);
        w3 = w4 | w3;
        w4 = (w3 >> 4) & 0xF;
        w4 = (w4 & ~(0xFFFFFFF0)) | (w3 << 4);
        w3 = (w4 ^ ~0x14) & 0xff;
        w4 = w3 ^ TmpTaBle[19];
        TmpTaBle[19] = w4;

        w8 = 0;
        w9 = 0;
        w22 = 0;
        w23 = 0;
        w27 = 0;
        w10 = 0;
        x2 = 0;
        w4 = 0;
        x5 = 6;
        w5 = 0;
        w3 = 0;
        int[] EncryptOut = new int[0x14];
        for (int i = 0; i < Data.length; i++) {
            w4 = ~0x55 & (TmpTaBle[i] << 1);
            w3 = 0x55 & (TmpTaBle[i] >>> 1);
            w3 = w4 | w3;
            w4 = w3 << 2;
            w4 = w4 & 0xffffffcf;
            w3 = 0x33 & (w3 >>> 2);
            w3 = w4 | w3;
            w4 = (w3 >> 4) & 0xF;
            w4 = (w4 & ~(0xFFFFFFF0)) | (w3 << 4);
            w3 = (w4 ^ ~0x14) & 0xff;
            EncryptOut[i] = w3;


        }


        StringBuilder hexString = new StringBuilder();
        for (int num : EncryptOut) {
            hexString.append(String.format("%02X ", num));
        }
        System.out.println("结果 = " + hexString.toString());
    }

    public static int bfi(int dest, int src, int lsb, int width) {
        int mask = (1 << width) - 1;
        int extractedBits = src & mask;
        dest &= ~(mask << lsb);
        dest |= extractedBits << lsb;
        return dest;
    }

}